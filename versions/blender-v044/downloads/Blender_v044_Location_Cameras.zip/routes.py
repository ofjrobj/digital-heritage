import bpy,math,json,bisect
from pathlib import Path
from mathutils import Vector
ROOT=Path('/Users/yoonjeongyeon/Documents/Codex/2026-10-01/blender-5-24fps-sun-light-area');OUT=ROOT/'outputs/village-v044';SRC=ROOT/'outputs/village-v043'
master=bpy.data.scenes['Gongju reference grounded village v043']
source=(SRC/'build.py').read_text();exec(source[source.index('def rawheight'):source.index('def mesh')],globals())
names=['Jegeumru_Merchant','Dongheon_Farmer','Guesthouse_Cook','Residential_Trio','Hillside_Woodcutter']
dest=json.loads((SRC/'layout.json').read_text())['destinations']
def ground(x,y,h):return (x,y,height(x,y)+h)
def ease(t):return t*t*t*(10+t*(-15+6*t))
def spline(points,u):
 ps=list(map(Vector,points));f=max(0,min(1,u))*(len(ps)-1);i=min(len(ps)-2,int(f));t=f-i;a=ps[max(0,i-1)];b=ps[i];c=ps[i+1];d=ps[min(len(ps)-1,i+2)]
 # Centripetal tangents reduce corner overshoot on unequally spaced segments.
 ab=max((b-a).length,.001)**.5;bc=max((c-b).length,.001)**.5;cd=max((d-c).length,.001)**.5
 m0=(c-a)*(bc/(ab+bc)) if i else c-b;m1=(d-b)*(bc/(bc+cd)) if i+2<len(ps) else c-b
 return (2*t**3-3*t*t+1)*b+(t**3-2*t*t+t)*m0+(-2*t**3+3*t*t)*c+(t**3-t*t)*m1
def arc(points,focus=None):
 dense=[spline(points,k/1500) for k in range(1501)];length=[0.]
 for a,b in zip(dense,dense[1:]):
  turn=0 if focus is None else (focus-a).normalized().angle((focus-b).normalized())
  length.append(length[-1]+(b-a).length+65*turn)
 def sample(u):
  distance=max(0,min(1,u))*length[-1];i=min(1499,max(0,bisect.bisect_right(length,distance)-1));t=(distance-length[i])/max(1e-8,length[i+1]-length[i]);return dense[i].lerp(dense[i+1],t)
 return sample
entries=[
 [(-65,-61,23),(-51,-44,9),(-39,-36,5),(-18,-30,4.6),(7,-26,4.6),(20,-26,4.6)],
 [(22,-42,17),(22,-25,7),(22,-12,5.1),(37,0,6.2),(40,20,6.3),(35,29,5.5),(30,30,5.2)],
 [(-66,-43,24),(-49,-15,8),(-41,6,6),(-29,14,6.6),(-27,21,6.8)],
 [(-1,-60,13),(-12,-48,6),(-14,-39,3.7),(-18,-38,3.5)],
 [ground(45,-16,14),ground(62,10,12),ground(59,32,7),ground(62,43,3),ground(64,45,2.8)]
]
# Each stop uses its own restrained motion: push-in, left truck, rise, right-to-left group reveal, uphill follow.
talks=[[(20,-26,4.6),(20.6,-25.3,4.4),(21,-24.8,4.3)],[(30,30,5.2),(29.2,30.3,5.2),(28.4,30.6,5.1)],[(-27,21,6.8),(-27,21.4,7),(-27,21.7,7.2)],[(-18,-38,3.5),(-19.4,-39,3.4),(-21,-39.4,3.4)],[ground(64,45,2.8),ground(64.4,45.7,2.6),ground(64.8,46.4,2.5)]]
exits=[
 [talks[0][-1],(27,-22,5),(42,-18,9),(58,-8,23),(70,12,42)],
 [talks[1][-1],(21,32,6),(8,34,9),(-9,33,16),(-37,32,35)],
 [talks[2][-1],(-27,22,11),(-27,25,19),(-27,33,34),(-27,44,48)],
 [talks[3][-1],(-31,-39,4.7),(-43,-36,7),(-55,-20,17),(-63,5,36)],
 [talks[4][-1],ground(69,51,5),ground(78,63,10),ground(91,81,18),(105,101,56)]
]
landmarks=[(-4,-26,3.6),(22,-12,5),(-28,25,5),(-23,-34,2),(65,51,height(65,51)+1.2)]
labels=['Street-level push through the residential lane toward the gate merchant','Gate underpass and east courtyard approach to the magistrate hall','Creek-side lane and stair ascent to the guesthouse cook','Between two homes, then a lateral reveal of the resident trio','Uphill trail tracking through trees toward the woodcutter']
routes=[]
for i in range(5):
 sc=master.copy();sc.name=names[i]+' location-specific camera v044';bpy.context.window.scene=sc
 cd=bpy.data.cameras.new(names[i]+' lens v044');cd.lens=32;cd.clip_start=.08;cd.clip_end=1000;cam=bpy.data.objects.new(names[i]+' camera v044',cd);sc.collection.objects.link(cam);sc.camera=cam;cam.rotation_mode='QUATERNION'
 hero=Vector((*dest[i],height(*dest[i])+1.2));entry=arc(entries[i]);talk=arc(talks[i]);leave=arc(exits[i],hero);samples=[];prev=None
 for frame in range(1,3458,2):
  t=(frame-1)/24
  if t<=90:
   u=ease(t/90);pos=entry(u)
   # Look ahead through the setting, blend onto the person before the decelerating arrival.
   aim=Vector(landmarks[i]);mix=ease(max(0,min(1,(u-.15)/.65)));target=aim.lerp(hero,mix)
   if i==1 and u<.35:target=Vector(landmarks[i]).lerp(target,ease(u/.35))
  elif t<=114:pos=talk(ease((t-90)/24));target=hero
  else:
   u=ease((t-114)/30);pos=leave(u);target=hero.lerp(Vector((dest[i][0],dest[i][1],hero.z+1)),u)
  q=(target-pos).to_track_quat('-Z','Y')
  if prev and prev.dot(q)<0:q.negate()
  cam.location=pos;cam.rotation_quaternion=q;cam.keyframe_insert('location',frame=frame);cam.keyframe_insert('rotation_quaternion',frame=frame);prev=q.copy();samples.append({'frame':frame,'position':list(pos),'target':list(target)})
 sc.frame_end=3457;sc.render.fps=24;sc.frame_set(1);sc['camera_direction']=labels[i]
 bpy.data.libraries.write(str(OUT/(names[i]+'_v044.blend')),{sc},path_remap='ABSOLUTE',fake_user=True,compress=True)
 routes.append({'index':i,'name':names[i],'scene':sc.name,'description':labels[i],'fps':24,'entryEnd':90,'talkEnd':114,'duration':144,'samples':samples})
(OUT/'blender-routes-v044.json').write_text(json.dumps(routes));result={'routes':5,'entry_seconds':90,'different_paths':labels}
